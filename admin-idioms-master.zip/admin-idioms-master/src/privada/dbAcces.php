<?php

class dbAccesData{
   public $serverName = "localhost";

   public $userName = "userDemo";
    
   public $password = "1234";
    
   public $dbName = "adminpanel";


}
