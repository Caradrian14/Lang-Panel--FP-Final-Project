<header class="bg-teal-800">
    <div class="flex p-6">
        <div class="flex-1 text-left">
            <h1 class="text-white text-xl">Panel de Administración de Idiomas</h1>
        </div>

        <div class="flex-1 ml-5 text-right items-end">
            <h4 class="text-white"><i class="fa fa-user" style="font-size:36px"></i> Perfil: Administrador</h4>
        </div>
    </div>
</header>