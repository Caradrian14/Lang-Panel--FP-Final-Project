 <aside class="flex-initial w-80 text-2xl text-center bg-teal-800">
     <nav>
         <ul>
             <a href="/?Controller=AdminText&method=getAll">
                 <li class="border-2 border-white bg-teal-500 px-12 hover:bg-teal-900 hover:text-white ease-in duration-300">
                     Ver Tags
                 </li>
             </a>
             <a href="/?Controller=AdminText&method=getLangListPage">
                 <li class="border-2 border-white bg-teal-500 px-12 hover:bg-teal-900 hover:text-white ease-in duration-300">
                     Ver Idiomas
                 </li>
             </a>
         </ul>
     </nav>
 </aside>