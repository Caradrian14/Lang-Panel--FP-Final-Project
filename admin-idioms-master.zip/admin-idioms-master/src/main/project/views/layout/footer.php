<footer class="bg-teal-800 pt-5 pb-5">
    <h1 class="text-white text-right mr-5">
        Desarrollado por Solutia
    </h1>
</footer>