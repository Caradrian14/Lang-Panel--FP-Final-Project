$(document).ready(function () {
  $("#dropdownDefaultButton").on("click", function () {
    $("#dropdown").toggleClass("hidden");
  });
});
