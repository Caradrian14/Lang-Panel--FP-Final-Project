# Panel de Administración de Idiomas
### Desarrollador por Adrià en la empresa Solutia, durante el periodo de Practicas de este.

### Datos Generales
- Nombre del Dominio: http://panelidiomas.local/
- Nombre de la Base de datos: adminpanel
- Usuario : userDemo
- Version de Php:  8.1.10

El objetivo de este proyecto es crear un panel para administrar gestionar textos en distintos idiomas y poder procesarlos despues en la parte publica comodamente y mostrar al cliente la traduccion que este disponible.